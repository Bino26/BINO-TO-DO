package my.b4a.todo;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends androidx.appcompat.app.AppCompatActivity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;
    public static boolean dontPause;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "my.b4a.todo", "my.b4a.todo.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "my.b4a.todo", "my.b4a.todo.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "my.b4a.todo.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        if (!dontPause)
            BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        else
            BA.LogInfo("** Activity (main) Pause event (activity is not paused). **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        if (!dontPause) {
            processBA.setActivityPaused(true);
            mostCurrent = null;
        }

        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.IME _ime = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example3.customlistview _clv = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlitem = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnledit = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnadd = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblcount = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltitledialog = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbldelete = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblno = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblyes = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblcheck = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltext = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txttodo = null;
public static int _id = 0;
public static int _white = 0;
public static int _lightgray = 0;
public b4a.example.dateutils _dateutils = null;
public my.b4a.todo.starter _starter = null;
public my.b4a.todo.xuiviewsutils _xuiviewsutils = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static void  _activity_create(boolean _firsttime) throws Exception{
ResumableSub_Activity_Create rsub = new ResumableSub_Activity_Create(null,_firsttime);
rsub.resume(processBA, null);
}
public static class ResumableSub_Activity_Create extends BA.ResumableSub {
public ResumableSub_Activity_Create(my.b4a.todo.main parent,boolean _firsttime) {
this.parent = parent;
this._firsttime = _firsttime;
}
my.b4a.todo.main parent;
boolean _firsttime;
anywheresoftware.b4a.objects.collections.Map _mapdata = null;
anywheresoftware.b4a.objects.collections.List _listtodo = null;
anywheresoftware.b4a.objects.collections.Map _maptodo = null;
anywheresoftware.b4a.BA.IterableList group6;
int index6;
int groupLen6;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 44;BA.debugLine="Activity.LoadLayout(\"Main\")";
parent.mostCurrent._activity.LoadLayout("Main",mostCurrent.activityBA);
 //BA.debugLineNum = 46;BA.debugLine="Wait For (Starter.kvs.GetMapAsync(Array(\"MapData\"";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", processBA, this, parent.mostCurrent._starter._kvs /*b4a.example3.keyvaluestore*/ ._getmapasync(anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)("MapData")})));
this.state = 13;
return;
case 13:
//C
this.state = 1;
_mapdata = (anywheresoftware.b4a.objects.collections.Map) result[0];
;
 //BA.debugLineNum = 48;BA.debugLine="If MapData.IsInitialized Then";
if (true) break;

case 1:
//if
this.state = 12;
if (_mapdata.IsInitialized()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 49;BA.debugLine="Dim ListTodo As List = MapData.Get(\"MapData\")";
_listtodo = new anywheresoftware.b4a.objects.collections.List();
_listtodo = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_mapdata.Get((Object)("MapData"))));
 //BA.debugLineNum = 50;BA.debugLine="If ListTodo.IsInitialized Then";
if (true) break;

case 4:
//if
this.state = 11;
if (_listtodo.IsInitialized()) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 51;BA.debugLine="For Each MapTodo As Map In ListTodo";
if (true) break;

case 7:
//for
this.state = 10;
_maptodo = new anywheresoftware.b4a.objects.collections.Map();
group6 = _listtodo;
index6 = 0;
groupLen6 = group6.getSize();
this.state = 14;
if (true) break;

case 14:
//C
this.state = 10;
if (index6 < groupLen6) {
this.state = 9;
_maptodo = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (anywheresoftware.b4a.objects.collections.Map.MyMap)(group6.Get(index6)));}
if (true) break;

case 15:
//C
this.state = 14;
index6++;
if (true) break;

case 9:
//C
this.state = 15;
 //BA.debugLineNum = 52;BA.debugLine="CLV.Add(CreateListItem(MapTodo.Get(\"txt\"), Map";
parent.mostCurrent._clv._add(_createlistitem(BA.ObjectToString(_maptodo.Get((Object)("txt"))),BA.ObjectToBoolean(_maptodo.Get((Object)("chk"))),parent.mostCurrent._clv._asview().getWidth(),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (70))),_maptodo.Get((Object)("id")));
 if (true) break;
if (true) break;

case 10:
//C
this.state = 11;
;
 if (true) break;

case 11:
//C
this.state = 12;
;
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 57;BA.debugLine="IME.Initialize(\"\")";
parent.mostCurrent._ime.Initialize("");
 //BA.debugLineNum = 58;BA.debugLine="ID = CLV.Size";
parent._id = parent.mostCurrent._clv._getsize();
 //BA.debugLineNum = 59;BA.debugLine="LblCount.Text = \"Taches: \" & CLV.Size";
parent.mostCurrent._lblcount.setText(BA.ObjectToCharSequence("Taches: "+BA.NumberToString(parent.mostCurrent._clv._getsize())));
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _complete(anywheresoftware.b4a.objects.collections.Map _mapdata) throws Exception{
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 62;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public static String  _btnadd_click() throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Sub BtnAdd_Click";
 //BA.debugLineNum = 117;BA.debugLine="LblTitleDialog.Text = \"N O U V E L L E (S)   T Â";
mostCurrent._lbltitledialog.setText(BA.ObjectToCharSequence("N O U V E L L E (S)   T Â C H E (S)"));
 //BA.debugLineNum = 118;BA.debugLine="TxtTodo.Text = \"\"";
mostCurrent._txttodo.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 119;BA.debugLine="TxtTodo.RequestFocus";
mostCurrent._txttodo.RequestFocus();
 //BA.debugLineNum = 120;BA.debugLine="LblDelete.Visible = False";
mostCurrent._lbldelete.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 121;BA.debugLine="PnlEdit.Visible = True";
mostCurrent._pnledit.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 122;BA.debugLine="BtnAdd.Visible = False";
mostCurrent._btnadd.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.B4XViewWrapper  _createlistitem(String _text,boolean _checked,int _width,int _height) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
 //BA.debugLineNum = 91;BA.debugLine="Sub CreateListItem(Text As String, Checked As Bool";
 //BA.debugLineNum = 92;BA.debugLine="Dim p As B4XView = XUI.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = mostCurrent._xui.CreatePanel(processBA,"");
 //BA.debugLineNum = 93;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, Width, Height)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_width,_height);
 //BA.debugLineNum = 94;BA.debugLine="p.LoadLayout(\"ListItem\")";
_p.LoadLayout("ListItem",mostCurrent.activityBA);
 //BA.debugLineNum = 96;BA.debugLine="LblCheck.Visible = Checked";
mostCurrent._lblcheck.setVisible(_checked);
 //BA.debugLineNum = 97;BA.debugLine="If Checked Then";
if (_checked) { 
 //BA.debugLineNum = 98;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 99;BA.debugLine="cs.Initialize";
_cs.Initialize();
 //BA.debugLineNum = 100;BA.debugLine="cs.Strikethrough.Append(Text).PopAll";
_cs.Strikethrough().Append(BA.ObjectToCharSequence(_text)).PopAll();
 //BA.debugLineNum = 101;BA.debugLine="LblText.Text = cs";
mostCurrent._lbltext.setText(BA.ObjectToCharSequence(_cs.getObject()));
 //BA.debugLineNum = 102;BA.debugLine="PnlItem.Color = LIGHTGRAY";
mostCurrent._pnlitem.setColor(_lightgray);
 }else {
 //BA.debugLineNum = 105;BA.debugLine="LblText.Text =  Text";
mostCurrent._lbltext.setText(BA.ObjectToCharSequence(_text));
 //BA.debugLineNum = 106;BA.debugLine="PnlItem.Color = WHITE";
mostCurrent._pnlitem.setColor(_white);
 };
 //BA.debugLineNum = 109;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return null;
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 22;BA.debugLine="Private IME As IME";
mostCurrent._ime = new anywheresoftware.b4a.objects.IME();
 //BA.debugLineNum = 23;BA.debugLine="Private XUI As XUI";
mostCurrent._xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 24;BA.debugLine="Private CLV As CustomListView";
mostCurrent._clv = new b4a.example3.customlistview();
 //BA.debugLineNum = 25;BA.debugLine="Private PnlItem As Panel";
mostCurrent._pnlitem = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private PnlEdit As Panel";
mostCurrent._pnledit = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private BtnAdd As Button";
mostCurrent._btnadd = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private LblCount As Label";
mostCurrent._lblcount = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private LblTitleDialog As Label";
mostCurrent._lbltitledialog = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private LblDelete As Label";
mostCurrent._lbldelete = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private LblNo As Label";
mostCurrent._lblno = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private LblYes As Label";
mostCurrent._lblyes = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private LblCheck As Label";
mostCurrent._lblcheck = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private LblText As Label";
mostCurrent._lbltext = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private TxtTodo As EditText";
mostCurrent._txttodo = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Dim ID As Int";
_id = 0;
 //BA.debugLineNum = 37;BA.debugLine="Dim const WHITE As Int = Colors.White";
_white = anywheresoftware.b4a.keywords.Common.Colors.White;
 //BA.debugLineNum = 38;BA.debugLine="Dim const LIGHTGRAY As Int = 0xFFF0F0F0";
_lightgray = (int) (0xfff0f0f0);
 //BA.debugLineNum = 40;BA.debugLine="Dim ID As Int";
_id = 0;
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static void  _lbldelete_click() throws Exception{
ResumableSub_LblDelete_Click rsub = new ResumableSub_LblDelete_Click(null);
rsub.resume(processBA, null);
}
public static class ResumableSub_LblDelete_Click extends BA.ResumableSub {
public ResumableSub_LblDelete_Click(my.b4a.todo.main parent) {
this.parent = parent;
}
my.b4a.todo.main parent;
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 175;BA.debugLine="If ID <> CLV.Size Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._id!=parent.mostCurrent._clv._getsize()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 176;BA.debugLine="CLV.RemoveAt(ID)";
parent.mostCurrent._clv._removeat(parent._id);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 178;BA.debugLine="Wait For (SaveTodo) Complete (Success As Boolean)";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", processBA, this, _savetodo());
this.state = 11;
return;
case 11:
//C
this.state = 5;
_success = (Boolean) result[0];
;
 //BA.debugLineNum = 179;BA.debugLine="If Success Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_success) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 180;BA.debugLine="IME.HideKeyboard";
parent.mostCurrent._ime.HideKeyboard(mostCurrent.activityBA);
 //BA.debugLineNum = 181;BA.debugLine="PnlEdit.Visible = False";
parent.mostCurrent._pnledit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 182;BA.debugLine="BtnAdd.Visible = True";
parent.mostCurrent._btnadd.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 183;BA.debugLine="LblCount.Text = \" T Â C H E S: \" & CLV.Size";
parent.mostCurrent._lblcount.setText(BA.ObjectToCharSequence(" T Â C H E S: "+BA.NumberToString(parent.mostCurrent._clv._getsize())));
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 185;BA.debugLine="ToastMessageShow(\"Error: Saving data\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Error: Saving data"),anywheresoftware.b4a.keywords.Common.False);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _lbledit_click() throws Exception{
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _pan = null;
anywheresoftware.b4a.objects.B4XViewWrapper _lbl = null;
 //BA.debugLineNum = 157;BA.debugLine="Sub LblEdit_Click";
 //BA.debugLineNum = 158;BA.debugLine="Dim index As Int = CLV.GetItemFromView(Sender)";
_index = mostCurrent._clv._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(anywheresoftware.b4a.keywords.Common.Sender(mostCurrent.activityBA))));
 //BA.debugLineNum = 159;BA.debugLine="Dim pnl As B4XView = CLV.GetPanel(index) ' ListIt";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = mostCurrent._clv._getpanel(_index);
 //BA.debugLineNum = 160;BA.debugLine="Dim pan As B4XView = pnl.GetView(0)		' PnlItem";
_pan = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pan = _pnl.GetView((int) (0));
 //BA.debugLineNum = 161;BA.debugLine="Dim lbl As B4XView = pan.GetView(1)		' LblText";
_lbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbl = _pan.GetView((int) (1));
 //BA.debugLineNum = 163;BA.debugLine="LblTitleDialog.Text = \"M O D I F I E R    T Â C H";
mostCurrent._lbltitledialog.setText(BA.ObjectToCharSequence("M O D I F I E R    T Â C H E"));
 //BA.debugLineNum = 164;BA.debugLine="TxtTodo.Text = lbl.Text";
mostCurrent._txttodo.setText(BA.ObjectToCharSequence(_lbl.getText()));
 //BA.debugLineNum = 165;BA.debugLine="LblDelete.Visible = True";
mostCurrent._lbldelete.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 166;BA.debugLine="PnlEdit.Visible = True";
mostCurrent._pnledit.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 167;BA.debugLine="BtnAdd.Visible = False";
mostCurrent._btnadd.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 168;BA.debugLine="TxtTodo.RequestFocus";
mostCurrent._txttodo.RequestFocus();
 //BA.debugLineNum = 169;BA.debugLine="TxtTodo.SelectionStart = TxtTodo.Text.Length";
mostCurrent._txttodo.setSelectionStart(mostCurrent._txttodo.getText().length());
 //BA.debugLineNum = 170;BA.debugLine="ID = index";
_id = _index;
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return "";
}
public static String  _lblno_click() throws Exception{
 //BA.debugLineNum = 233;BA.debugLine="Sub LblNo_Click";
 //BA.debugLineNum = 234;BA.debugLine="IME.HideKeyboard";
mostCurrent._ime.HideKeyboard(mostCurrent.activityBA);
 //BA.debugLineNum = 235;BA.debugLine="PnlEdit.Visible = False";
mostCurrent._pnledit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 236;BA.debugLine="BtnAdd.Visible = True";
mostCurrent._btnadd.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 237;BA.debugLine="End Sub";
return "";
}
public static void  _lblyes_click() throws Exception{
ResumableSub_LblYes_Click rsub = new ResumableSub_LblYes_Click(null);
rsub.resume(processBA, null);
}
public static class ResumableSub_LblYes_Click extends BA.ResumableSub {
public ResumableSub_LblYes_Click(my.b4a.todo.main parent) {
this.parent = parent;
}
my.b4a.todo.main parent;
String _str = "";
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _pan = null;
anywheresoftware.b4a.objects.B4XViewWrapper _chk = null;
anywheresoftware.b4a.objects.B4XViewWrapper _lbl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _txt = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 190;BA.debugLine="Dim str As String";
_str = "";
 //BA.debugLineNum = 191;BA.debugLine="If LblTitleDialog.Text = \"M O D I F I E R    T Â";
if (true) break;

case 1:
//if
this.state = 23;
if ((parent.mostCurrent._lbltitledialog.getText()).equals("M O D I F I E R    T Â C H E")) { 
this.state = 3;
}else {
this.state = 16;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 192;BA.debugLine="Dim pnl As B4XView = CLV.GetPanel(ID)	' ListItem";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = parent.mostCurrent._clv._getpanel(parent._id);
 //BA.debugLineNum = 193;BA.debugLine="Dim pan As B4XView = pnl.GetView(0)		' PnlItem";
_pan = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pan = _pnl.GetView((int) (0));
 //BA.debugLineNum = 194;BA.debugLine="Dim chk As B4XView = pan.GetView(0)		' PnlCheck";
_chk = new anywheresoftware.b4a.objects.B4XViewWrapper();
_chk = _pan.GetView((int) (0));
 //BA.debugLineNum = 195;BA.debugLine="Dim lbl As B4XView = chk.GetView(0)		' LblCheck";
_lbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbl = _chk.GetView((int) (0));
 //BA.debugLineNum = 196;BA.debugLine="Dim txt As B4XView = pan.GetView(1)		' LblText";
_txt = new anywheresoftware.b4a.objects.B4XViewWrapper();
_txt = _pan.GetView((int) (1));
 //BA.debugLineNum = 198;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 199;BA.debugLine="cs.Initialize";
_cs.Initialize();
 //BA.debugLineNum = 201;BA.debugLine="If TxtTodo.Text.Trim = \"\" Then";
if (true) break;

case 4:
//if
this.state = 9;
if ((parent.mostCurrent._txttodo.getText().trim()).equals("")) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 9;
 //BA.debugLineNum = 202;BA.debugLine="str = $\"Item #${ID + 1}\"$";
_str = ("Item #"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(parent._id+1))+"");
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 204;BA.debugLine="str = TxtTodo.Text.Trim";
_str = parent.mostCurrent._txttodo.getText().trim();
 if (true) break;
;
 //BA.debugLineNum = 206;BA.debugLine="If lbl.Visible Then";

case 9:
//if
this.state = 14;
if (_lbl.getVisible()) { 
this.state = 11;
}else {
this.state = 13;
}if (true) break;

case 11:
//C
this.state = 14;
 //BA.debugLineNum = 207;BA.debugLine="cs.Strikethrough.Append(str).PopAll";
_cs.Strikethrough().Append(BA.ObjectToCharSequence(_str)).PopAll();
 if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 209;BA.debugLine="cs.Append(str).PopAll";
_cs.Append(BA.ObjectToCharSequence(_str)).PopAll();
 if (true) break;

case 14:
//C
this.state = 23;
;
 //BA.debugLineNum = 211;BA.debugLine="txt.Text = cs";
_txt.setText(BA.ObjectToCharSequence(_cs.getObject()));
 if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 213;BA.debugLine="ID = CLV.Size";
parent._id = parent.mostCurrent._clv._getsize();
 //BA.debugLineNum = 214;BA.debugLine="If TxtTodo.Text.Trim = \"\" Then";
if (true) break;

case 17:
//if
this.state = 22;
if ((parent.mostCurrent._txttodo.getText().trim()).equals("")) { 
this.state = 19;
}else {
this.state = 21;
}if (true) break;

case 19:
//C
this.state = 22;
 //BA.debugLineNum = 215;BA.debugLine="str = $\"Item #${ID + 1}\"$";
_str = ("Item #"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(parent._id+1))+"");
 if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 217;BA.debugLine="str = TxtTodo.Text.Trim";
_str = parent.mostCurrent._txttodo.getText().trim();
 if (true) break;

case 22:
//C
this.state = 23;
;
 //BA.debugLineNum = 219;BA.debugLine="CLV.Add(CreateListItem(str, False, CLV.AsView.Wi";
parent.mostCurrent._clv._add(_createlistitem(_str,anywheresoftware.b4a.keywords.Common.False,parent.mostCurrent._clv._asview().getWidth(),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (70))),(Object)(parent._id));
 if (true) break;

case 23:
//C
this.state = 24;
;
 //BA.debugLineNum = 221;BA.debugLine="Wait For (SaveTodo) Complete (Success As Boolean)";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", processBA, this, _savetodo());
this.state = 30;
return;
case 30:
//C
this.state = 24;
_success = (Boolean) result[0];
;
 //BA.debugLineNum = 222;BA.debugLine="If Success Then";
if (true) break;

case 24:
//if
this.state = 29;
if (_success) { 
this.state = 26;
}else {
this.state = 28;
}if (true) break;

case 26:
//C
this.state = 29;
 //BA.debugLineNum = 223;BA.debugLine="IME.HideKeyboard";
parent.mostCurrent._ime.HideKeyboard(mostCurrent.activityBA);
 //BA.debugLineNum = 224;BA.debugLine="PnlEdit.Visible = False";
parent.mostCurrent._pnledit.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 225;BA.debugLine="BtnAdd.Visible = True";
parent.mostCurrent._btnadd.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 227;BA.debugLine="LblCount.Text = \"T Â C H E S: \" & CLV.Size";
parent.mostCurrent._lblcount.setText(BA.ObjectToCharSequence("T Â C H E S: "+BA.NumberToString(parent.mostCurrent._clv._getsize())));
 if (true) break;

case 28:
//C
this.state = 29;
 //BA.debugLineNum = 229;BA.debugLine="ToastMessageShow(\"Error: Saving data\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Error: Saving data"),anywheresoftware.b4a.keywords.Common.False);
 if (true) break;

case 29:
//C
this.state = -1;
;
 //BA.debugLineNum = 231;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _noscroll_click() throws Exception{
 //BA.debugLineNum = 239;BA.debugLine="Sub NoScroll_Click";
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
return "";
}
public static void  _pnlcheck_click() throws Exception{
ResumableSub_PnlCheck_Click rsub = new ResumableSub_PnlCheck_Click(null);
rsub.resume(processBA, null);
}
public static class ResumableSub_PnlCheck_Click extends BA.ResumableSub {
public ResumableSub_PnlCheck_Click(my.b4a.todo.main parent) {
this.parent = parent;
}
my.b4a.todo.main parent;
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _pan = null;
anywheresoftware.b4a.objects.B4XViewWrapper _chk = null;
anywheresoftware.b4a.objects.B4XViewWrapper _lbl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _txt = null;
anywheresoftware.b4a.objects.CSBuilder _cs = null;
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 126;BA.debugLine="Dim index As Int = CLV.GetItemFromView(Sender)";
_index = parent.mostCurrent._clv._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(anywheresoftware.b4a.keywords.Common.Sender(mostCurrent.activityBA))));
 //BA.debugLineNum = 127;BA.debugLine="ID = index";
parent._id = _index;
 //BA.debugLineNum = 128;BA.debugLine="Dim pnl As B4XView = CLV.GetPanel(ID) ' ListItem";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = parent.mostCurrent._clv._getpanel(parent._id);
 //BA.debugLineNum = 129;BA.debugLine="Dim pan As B4XView = pnl.GetView(0)		' PnlItem";
_pan = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pan = _pnl.GetView((int) (0));
 //BA.debugLineNum = 130;BA.debugLine="Dim chk As B4XView = pan.GetView(0)		' PnlCheck";
_chk = new anywheresoftware.b4a.objects.B4XViewWrapper();
_chk = _pan.GetView((int) (0));
 //BA.debugLineNum = 131;BA.debugLine="Dim lbl As B4XView = chk.GetView(0)		' LblCheck";
_lbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbl = _chk.GetView((int) (0));
 //BA.debugLineNum = 132;BA.debugLine="Dim txt As B4XView = pan.GetView(1)		' LblText";
_txt = new anywheresoftware.b4a.objects.B4XViewWrapper();
_txt = _pan.GetView((int) (1));
 //BA.debugLineNum = 134;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 135;BA.debugLine="cs.Initialize";
_cs.Initialize();
 //BA.debugLineNum = 137;BA.debugLine="lbl.Visible = Not(lbl.Visible)";
_lbl.setVisible(anywheresoftware.b4a.keywords.Common.Not(_lbl.getVisible()));
 //BA.debugLineNum = 138;BA.debugLine="If lbl.Visible Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_lbl.getVisible()) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 139;BA.debugLine="pan.Color = LIGHTGRAY";
_pan.setColor(parent._lightgray);
 //BA.debugLineNum = 140;BA.debugLine="chk.Color = LIGHTGRAY";
_chk.setColor(parent._lightgray);
 //BA.debugLineNum = 142;BA.debugLine="cs.Strikethrough.Append(txt.Text).PopAll";
_cs.Strikethrough().Append(BA.ObjectToCharSequence(_txt.getText())).PopAll();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 144;BA.debugLine="pan.Color = WHITE";
_pan.setColor(parent._white);
 //BA.debugLineNum = 145;BA.debugLine="chk.Color = WHITE";
_chk.setColor(parent._white);
 //BA.debugLineNum = 147;BA.debugLine="cs.Append(txt.Text).PopAll";
_cs.Append(BA.ObjectToCharSequence(_txt.getText())).PopAll();
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 149;BA.debugLine="txt.Text = cs";
_txt.setText(BA.ObjectToCharSequence(_cs.getObject()));
 //BA.debugLineNum = 150;BA.debugLine="ID = index";
parent._id = _index;
 //BA.debugLineNum = 151;BA.debugLine="Wait For (SaveTodo) Complete (Success As Boolean)";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", processBA, this, _savetodo());
this.state = 11;
return;
case 11:
//C
this.state = 7;
_success = (Boolean) result[0];
;
 //BA.debugLineNum = 152;BA.debugLine="If Success = False Then";
if (true) break;

case 7:
//if
this.state = 10;
if (_success==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 153;BA.debugLine="ToastMessageShow(\"Error: Saving data\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Error: Saving data"),anywheresoftware.b4a.keywords.Common.False);
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 155;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4a.example.dateutils._process_globals();
main._process_globals();
starter._process_globals();
xuiviewsutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _savetodo() throws Exception{
ResumableSub_SaveTodo rsub = new ResumableSub_SaveTodo(null);
rsub.resume(processBA, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SaveTodo extends BA.ResumableSub {
public ResumableSub_SaveTodo(my.b4a.todo.main parent) {
this.parent = parent;
}
my.b4a.todo.main parent;
anywheresoftware.b4a.objects.collections.List _listtodo = null;
int _i = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _pan = null;
anywheresoftware.b4a.objects.B4XViewWrapper _chk = null;
anywheresoftware.b4a.objects.B4XViewWrapper _lbl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _txt = null;
anywheresoftware.b4a.objects.collections.Map _maptodo = null;
anywheresoftware.b4a.objects.collections.Map _mapdata = null;
boolean _success = false;
int step3;
int limit3;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 72;BA.debugLine="Dim ListTodo As List";
_listtodo = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 73;BA.debugLine="ListTodo.Initialize";
_listtodo.Initialize();
 //BA.debugLineNum = 75;BA.debugLine="For i = 0 To CLV.Size - 1";
if (true) break;

case 1:
//for
this.state = 4;
step3 = 1;
limit3 = (int) (parent.mostCurrent._clv._getsize()-1);
_i = (int) (0) ;
this.state = 5;
if (true) break;

case 5:
//C
this.state = 4;
if ((step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3)) this.state = 3;
if (true) break;

case 6:
//C
this.state = 5;
_i = ((int)(0 + _i + step3)) ;
if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 76;BA.debugLine="Dim pnl As B4XView = CLV.GetPanel(i)";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = parent.mostCurrent._clv._getpanel(_i);
 //BA.debugLineNum = 77;BA.debugLine="Dim pan As B4XView = pnl.GetView(0)		' PnlItem";
_pan = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pan = _pnl.GetView((int) (0));
 //BA.debugLineNum = 78;BA.debugLine="Dim chk As B4XView = pan.GetView(0)		' PnlCheck";
_chk = new anywheresoftware.b4a.objects.B4XViewWrapper();
_chk = _pan.GetView((int) (0));
 //BA.debugLineNum = 79;BA.debugLine="Dim lbl As B4XView = chk.GetView(0)		' LblCheck";
_lbl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_lbl = _chk.GetView((int) (0));
 //BA.debugLineNum = 80;BA.debugLine="Dim txt As B4XView = pan.GetView(1)		' LblText";
_txt = new anywheresoftware.b4a.objects.B4XViewWrapper();
_txt = _pan.GetView((int) (1));
 //BA.debugLineNum = 82;BA.debugLine="Dim MapTodo As Map = CreateMap(\"id\": i, \"chk\": l";
_maptodo = new anywheresoftware.b4a.objects.collections.Map();
_maptodo = anywheresoftware.b4a.keywords.Common.createMap(new Object[] {(Object)("id"),(Object)(_i),(Object)("chk"),(Object)(_lbl.getVisible()),(Object)("txt"),(Object)(_txt.getText())});
 //BA.debugLineNum = 83;BA.debugLine="ListTodo.Add(MapTodo)";
_listtodo.Add((Object)(_maptodo.getObject()));
 if (true) break;
if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 86;BA.debugLine="Dim MapData As Map = CreateMap(\"MapData\":ListTodo";
_mapdata = new anywheresoftware.b4a.objects.collections.Map();
_mapdata = anywheresoftware.b4a.keywords.Common.createMap(new Object[] {(Object)("MapData"),(Object)(_listtodo.getObject())});
 //BA.debugLineNum = 87;BA.debugLine="Wait For (Starter.kvs.PutMapAsync(MapData)) Compl";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", processBA, this, parent.mostCurrent._starter._kvs /*b4a.example3.keyvaluestore*/ ._putmapasync(_mapdata));
this.state = 7;
return;
case 7:
//C
this.state = -1;
_success = (Boolean) result[0];
;
 //BA.debugLineNum = 88;BA.debugLine="Return Success";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_success));return;};
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
}
